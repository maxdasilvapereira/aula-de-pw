package com.etecja.testingspringbootaplication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestingSpringBootAplicationApplication {

	public static void main(String[] args) {
		SpringApplication.run(TestingSpringBootAplicationApplication.class, args);
	}

}
